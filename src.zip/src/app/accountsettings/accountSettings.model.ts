export class AccountSettingsCustomer {
  mobileNo: any;
  dialCode: any;
  active: string;
  roleCode: string;
  email: string;
  firstName: string;
  lastName: string;
  address: string;
  pictureType: string;
  pictureUrl: string;
  country: string;
  adminAreaLevel1: string;
  adminAreaLevel2: string;
  subLocality: string;
  locality: string;
  location: string;
  postalCode: string;
  latitude: string;
  longitude: string;
  googleAddress: string;
}
