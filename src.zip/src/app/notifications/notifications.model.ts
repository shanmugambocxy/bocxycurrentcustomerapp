export class CustomerNotifications {
  customerNotificationId: number;
  accountId: number;
  type: string;
  announcementId: number;
  appointmentId: number;
  read: string;
  count: number;
  StoreName: string;
  StoreNameCanceled: string;
  title: string;
  content: string;
  annoucementCreatedTime: any;
}
