import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-servicedetail',
  templateUrl: './view-servicedetail.page.html',
  styleUrls: ['./view-servicedetail.page.scss'],
})
export class ViewServicedetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
