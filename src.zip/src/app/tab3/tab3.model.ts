export class Appointments {
  appointmentId: number;
  createdAt: string;
  location: string;
  serviceName: string;
  slotName: string;
  stylistName: string;
  status: string;
  storeName: string;
  totalAmount: string;
  cancelReason: string;
}
