export class AppointmentBookingResponse {
  bookedFlag: boolean;
  appointmentId: number;
  bookingId: string;
}
