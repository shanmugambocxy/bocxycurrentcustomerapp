export class MerchantStore {
  merchantStoreId: number;
  name: string;
  locality: string;
  display: string;
}
