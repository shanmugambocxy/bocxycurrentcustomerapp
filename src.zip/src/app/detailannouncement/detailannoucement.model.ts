export class detailAnnoucementCustomer {
  _storeName: any;
  announcementId: any;
  merchantStoreId: any;
  customerType: string;
  title: string;
  content: string;
  status: string;
  createdAt: any;
}
